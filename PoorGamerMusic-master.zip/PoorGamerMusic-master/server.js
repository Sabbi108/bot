const Bot = require("ctk-musicbot");

const musicbot = new Bot({
  Token: "NzQyMzk2NzE1NjI5NTQzNDk1.XzFg0g.bQexwnlsJysoALY1mEjP35MbUVk",
  prefix: "#"
});

musicbot.start();

